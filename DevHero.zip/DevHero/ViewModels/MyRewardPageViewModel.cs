﻿using DevHero.Models;
using DevHero.Services;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace DevHero.ViewModels
{
   public class MyRewardPageViewModel : BindableBase, INavigatedAware
    {
        private IRankService _rankService;
        private IRewardService _rewardService;
        public int IdUser = 1;
        public DelegateCommand<object> UseReward { get; private set; } // delegate command

        public List<Reward> _rewards;
        public List<Reward> Rewards
        {
            get { return _rewards; }
            set { SetProperty(ref _rewards, value); }
        }
        public MyRewardPageViewModel(INavigationService navigationService, IRankService rankService, IRewardService rewardService)
        {
            _rankService = rankService;
            _rewardService = rewardService;
            Rewards = _rewardService.GetRewardsPerUser(IdUser);
            UseReward = new DelegateCommand<object>(Use);

        }
        void Use(object obj)
        {
            var idreward = obj as Label;
            var id = int.Parse(idreward.Text);
            _rewardService.UseReward(id, IdUser);
            Rewards = _rewardService.GetRewardsPerUser(IdUser);
        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
