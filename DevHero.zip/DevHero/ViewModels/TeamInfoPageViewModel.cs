﻿using DevHero.Models;
using DevHero.Services;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.ViewModels
{
   public class TeamInfoPageViewModel : BindableBase, INavigatedAware
    {
        private IUserService _userService;
        private List<User> _users;

        public List<User> Users
        {
            get { return _users; }
            set { SetProperty(ref _users, value); }
        }
        public int IdTeam { get; set; }
        public TeamInfoPageViewModel(INavigationService navigationService, IUserService userService)
        {
            _userService = userService;
            
        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            if (parameters.TryGetValue(KnownNavigationParameters.XamlParam, out object value))
            {
                IdTeam = (int)value;
            }
            Users = _userService.GetUsersTeam(IdTeam);
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.TryGetValue(KnownNavigationParameters.XamlParam, out object value))
            {
                IdTeam = (int)value;
            }
            Users = _userService.GetUsersTeam(IdTeam);
        }
    }
}
