﻿using DevHero.Models;
using DevHero.Services;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.ViewModels
{
    class RewardPageViewModel : BindableBase, INavigatedAware
    {
        private IRewardService _rewardService;
        public int IdRank { get; set; }
        private List<Reward> _rewards;

        public List<Reward> Rewards
        {
            get { return _rewards; }
            set { SetProperty(ref _rewards, value); }
        }

        public RewardPageViewModel(INavigationService navigationService, IRewardService rewardService)
        {
            _rewardService = rewardService;
            Rewards = _rewardService.GetRewards();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.TryGetValue(KnownNavigationParameters.XamlParam, out object value))
            {
                IdRank = (int)value;
                Rewards = _rewardService.GetReward(IdRank);
            }
        }
    }
}
