﻿using DevHero.Models;
using DevHero.Services;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;

namespace DevHero.ViewModels

{
    class ShopRankPageViewModel : BindableBase, INavigatedAware
    {
        private IRankService _rankService;
        private List<Rank> _ranks;
        public DelegateCommand<object> ClaimRank { get; private set; } // commande delegué au viewmodel



        public List<Rank> Ranks
        {
            get { return _ranks; }
            set { SetProperty(ref _ranks, value); }
        }

        public ShopRankPageViewModel(INavigationService navigationService, IRankService rankService)
        {
            _rankService = rankService;
            Ranks = _rankService.GetRanks();
            ClaimRank = new DelegateCommand<object>(Submit); //
        }

        void Submit(object obj)
        {
            var test = obj as Label;
            var id = int.Parse(test.Text); // permet de recupérer l'id du rank selectionner
            _rankService.ClaimRank(id); // appel la methode ClaimRank pour acheter un rank 
        }

        protected INavigationService NavigationService { get; private set; }


        public ShopRankPageViewModel(INavigationService navigationService)
        {
            NavigationService = navigationService;
        }

        private bool canExecuteMethod()
        {
            return true;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {

        }
    }
}