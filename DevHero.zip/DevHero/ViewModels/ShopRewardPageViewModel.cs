﻿using DevHero.Models;
using DevHero.Services;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using Xamarin.Forms;
namespace DevHero.ViewModels
{
    class ShopRewardPageViewModel : BindableBase, INavigatedAware
    {
        private IRewardService _rewardService;
        public int IdRank { get; set; }
        private List<Reward> _rewards;
        public DelegateCommand<object> ClaimReward { get; private set; }
        public List<Reward> Rewards
        {
            get { return _rewards; }
            set { SetProperty(ref _rewards, value); }
        }
        public ShopRewardPageViewModel(INavigationService navigationService, IRewardService rewardService)
        {
            _rewardService = rewardService;
            ClaimReward = new DelegateCommand<object>(Submit);
        }
        void Submit(object obj)
        {
            var test = obj as Label;
            var id = int.Parse(test.Text);
            _rewardService.ClaimReward(id);
        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }
        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.TryGetValue(KnownNavigationParameters.XamlParam, out object value))
            {
                IdRank = (int)value;
            }
            Rewards = _rewardService.GetReward(IdRank);
        }
    }
}