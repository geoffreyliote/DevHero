﻿using System;
using System.Collections.Generic;
using System.Text;
using DevHero.Models;
using DevHero.Services;
using Prism.Mvvm;
using Prism.Navigation;

namespace DevHero.ViewModels
{
    class TabPageViewModel : BindableBase, INavigatedAware
    {
        string Log { get; set; }
        string Mdp { get; set; }
        private INavigationService _navigationService;
        private IRankService _rankService;
        private List<Rank> _ranks;

        public TabPageViewModel(INavigationService navigationService, RankService rankService)
        {
            _navigationService = navigationService;
            _rankService = rankService;
        }


        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            if (parameters.TryGetValue(KnownNavigationParameters.XamlParam, out object value))
            {
            }
            Log = parameters.GetValue<string>("Id");
            Mdp = parameters.GetValue<string>("Mdp");
        }

        public List<Rank> Ranks
        {
            get => _ranks;
            set => SetProperty(ref _ranks, value);
        }
    }
}
