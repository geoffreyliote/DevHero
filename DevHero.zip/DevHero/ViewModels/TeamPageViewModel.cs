﻿using DevHero.Models;
using DevHero.Services;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace DevHero.ViewModels
{
    public class TeamPageViewModel : BindableBase, INavigatedAware
    {
        private ITeamService _teamService;
        public int IdTeam { get; set; }
        private List<Team> _teams;

        public List<Team> Teams
        {
            get { return _teams; }
            set { SetProperty(ref _teams, value); }
        }

        public TeamPageViewModel(INavigationService navigationService, ITeamService teamService)
        {
            _teamService = teamService;
            Teams = _teamService.GetTeam();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        
        }
    }
}
