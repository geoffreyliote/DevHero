﻿using DevHero.Models;
using DevHero.Services;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DevHero.ViewModels

{
    class RankPageViewModel : BindableBase, INavigatedAware
    {
        private IRankService _rankService;


        private List<Rank> _ranks;
        public List<Rank> Ranks
        {
            get { return _ranks; }
            set { SetProperty(ref _ranks, value); }
        }

        public RankPageViewModel(INavigationService navigationService, IRankService rankService)
        {
            _rankService = rankService;
            Ranks = _rankService.GetRanks();
        }

        protected INavigationService NavigationService { get; private set; }


        public RankPageViewModel(INavigationService navigationService)
        {
            NavigationService = navigationService;
        }

        private bool canExecuteMethod()
        {
            return true;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {

        }
    }
}

