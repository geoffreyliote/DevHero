﻿using System;
using System.Collections.Generic;
using System.Text;
using Prism.Mvvm;
using Prism.Navigation;

namespace DevHero.ViewModels
{
    class LoginPageViewModel : BindableBase, INavigatedAware
    {
        private INavigationService _navigationService;



        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
