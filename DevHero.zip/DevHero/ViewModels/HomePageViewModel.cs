﻿using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.ViewModels
{
   public class HomePageViewModel : BindableBase, INavigatedAware
    {
        private INavigationService _navigationService;



        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
 