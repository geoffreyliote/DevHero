﻿using DevHero.Models;
using DevHero.Services;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Text;
namespace DevHero.ViewModels
{
    class RewardStatusPageViewModel : BindableBase, INavigatedAware
    {
        private IRewardService _rewardService;
        public int IdUser = 1;
        public List<UserReward> _rewards;
        public List<UserReward> Rewards
        {
            get { return _rewards; }
            set { SetProperty(ref _rewards, value); }
        }
        public RewardStatusPageViewModel(INavigationService navigationService, IRewardService rewardService)
        {
            _rewardService = rewardService;

            Rewards = _rewardService.GetRewardsInfo(IdUser);

        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }
        public void OnNavigatedTo(INavigationParameters parameters)
        {

        }
    }
}

