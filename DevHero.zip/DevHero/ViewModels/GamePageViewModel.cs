﻿using System;
using System.Collections.Generic;
using System.Text;
using DevHero.Models;
using DevHero.Services;
using Prism.Mvvm;
using Prism.Navigation;
namespace DevHero.ViewModels
{
    public class GamePageViewModel : BindableBase, INavigatedAware
    {
        private INavigationService _navigationService;
        private IUserService _userService;
        private IRankService _rankService;
        public int IdUser = 1;
        public User Connected_user { get; set; }
        public Rank User_rank { get; set; }

        List<User> Users { get; set; }

        public GamePageViewModel(INavigationService navigationService, IUserService userService, IRankService rankService)
        {
            Users = userService.GetUsers();
            _userService = userService;
            _navigationService = navigationService;
            _rankService = rankService;
            Connected_user = _userService.GetUser(IdUser);
            User_rank = Connected_user.Rank;
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
