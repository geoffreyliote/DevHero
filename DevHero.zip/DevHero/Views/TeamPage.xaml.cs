﻿using Xamarin.Forms;
namespace DevHero.Views
{
    public partial class TeamPage : ContentPage
    {
        public TeamPage()
        {
            InitializeComponent();
        }
    }
}