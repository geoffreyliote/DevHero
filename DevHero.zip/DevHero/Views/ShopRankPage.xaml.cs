﻿
using Xamarin.Forms;
namespace DevHero.Views
{
    public partial class ShopRankPage : ContentPage
    {
        public ShopRankPage()
        {
            InitializeComponent();

        }
    }
}