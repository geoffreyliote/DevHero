﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Models
{
   public class UserReward
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
        public string Description { get; set; }
        public int User_id { get; set; }
        public DateTime Request_date { get; set; }

        public UserReward()
        {

        }
    }
}
