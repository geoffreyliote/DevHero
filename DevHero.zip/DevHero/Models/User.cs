﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public int Experience { get; set; }
        public string Skin { get; set; }
        public int RankId { get; set; }
        public string Mail { get; set; }
        public string Phone { get; set; }
        public DateTime Birthdate { get; set; }
        public List<Reward> Rewards { get; set; }
        public Rank Rank { get; set; }

        public User()
        {

        }
    }
}
