﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Models
{
    public class Team
    {
        public int Id { get; set; }
        public int Leader_Id { get; set; }
        public int Experience { get; set; }
        public DateTime Creation_date { get; set; }
        public string Name { get; set; }
    }
}
