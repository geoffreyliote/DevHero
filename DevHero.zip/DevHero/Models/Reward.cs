﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Models
{
    public class Reward
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int Price { get; set; }
        public int Nb_max_uses { get; set; }
        public int Nb_actuel_uses { get; set; }
        public int Id_rank { get; set; }
        public string Image { get; set; }
        public State State { get; set; }
        public List<UserReward> Users { get; set; }

        public Reward()
        {

        }
    }
}
