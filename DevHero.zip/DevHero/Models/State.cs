﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Models
{
  public class State
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
