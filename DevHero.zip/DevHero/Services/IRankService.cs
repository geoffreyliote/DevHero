﻿using DevHero.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Services
{
    public interface IRankService
    {
        List<Rank> Ranks { get; set; }
        List<Rank> GetRankAndRewards();
        List<Rank> GetRanks();
        void ClaimRank(int idRank);
    }
}
