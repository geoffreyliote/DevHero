﻿using DevHero.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace DevHero.Services
{
    public class RewardService : IRewardService
    {
        public List<Reward> Rewards { get; set; }
        static HttpClient client = new HttpClient();
        int idUser = 1;
        public RestRequest restRequest { get; set; }

        public RewardService()
        {

        }

        public List<Reward> GetReward(int idRank)
        {
            return JsonConvert.DeserializeObject<List<Reward>>(client.GetStringAsync("http://devhero.test/api/rewards/" + idRank).Result);
        }

        public List<Reward> GetRewards()
        {
            return Rewards;
        }
        public List<Reward> GetRewardsPerUser(int idUser)
        {
            string json = (client.GetStringAsync("http://devhero.test/api/usereward/" + idUser).Result);
            List<Reward> reward = JsonConvert.DeserializeObject<List<Reward>>(json);
            return reward;
        }       
        public List<UserReward> GetRewardsInfo(int idUser)
        {
            string json = (client.GetStringAsync("http://devhero.test/api/rewardsinfo/" + idUser).Result);
            List<UserReward> reward = JsonConvert.DeserializeObject<List<UserReward>>(json);
            return reward;
        }

        void IRewardService.UseReward(int idReward, int idUser)
        {
            var restClient = new RestClient();
            restRequest = new RestRequest("http://devhero.test/api/usereward", Method.POST);
            restRequest.AddParameter("reward_id", idReward);
            restRequest.AddParameter("user_id", idUser);
            restClient.Post(restRequest);
        }
        void IRewardService.ClaimReward(int idReward)
        {
            var restClient = new RestClient();
            restRequest = new RestRequest("http://devhero.test/api/claimreward", Method.POST);
            restRequest.AddParameter("reward_id", idReward);
            restRequest.AddParameter("user_id", idUser); // id du user en brute
            restClient.Post(restRequest);
        }
    }
}
