﻿using DevHero.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Services
{
    public interface IUserService
    {
        User User { get; set; }
        List<Reward> GetRewards(int idUser);
        User GetRank(int idUser);
        List<User> GetUsers();
        User GetUser(int id);
        List<User> GetUsersTeam(int idTeam);

    }
}
