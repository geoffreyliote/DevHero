﻿using DevHero.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Services
{
    public interface ITeamService
    {
        List<Team> Teams { get; set; } 
        List<Team> GetTeam();


    }
}
