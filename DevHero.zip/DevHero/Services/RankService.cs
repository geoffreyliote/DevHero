﻿using DevHero.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;

namespace DevHero.Services
{
    public class RankService : IRankService
    {
        static HttpClient client = new HttpClient();
        public List<Rank> Ranks { get; set; }
        int idUser = 1;

        public RestRequest restRequest { get; set; }
        public RankService()
        {
           
        }

        List<Rank> IRankService.Ranks { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        List<Rank> IRankService.GetRanks()
        {
           
            return JsonConvert.DeserializeObject<List<Rank>>( client.GetStringAsync("http://devhero.test/api/ranks").Result);
        }

        public void LoadJson()
        {
            using (StreamReader r = new StreamReader("rank.json"))
            {
                string json = r.ReadToEnd();
                Ranks = JsonConvert.DeserializeObject<List<Rank>>(json);
            }
        }
        List<Rank> IRankService.GetRankAndRewards()
        {
            return JsonConvert.DeserializeObject<List<Rank>>(client.GetStringAsync("http://devhero.test/api/rankinfos").Result);
        }


        void IRankService.ClaimRank(int idRank)
        {
            var restClient = new RestClient();
            restRequest = new RestRequest("http://devhero.test/api/claimrank", Method.POST);
            restRequest.AddParameter("rank_id", idRank);
            restRequest.AddParameter("user_id", idUser); // id du user en brute


            restClient.Post(restRequest);
        }







    }
}
