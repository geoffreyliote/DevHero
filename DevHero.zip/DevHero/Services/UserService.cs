﻿using DevHero.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

namespace DevHero.Services
{
    class UserService : IUserService
    {
        static HttpClient client = new HttpClient();

        public UserService()
        {

        }

        public User User { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public User GetRank(int idUser)
        {
            return JsonConvert.DeserializeObject<User>(client.GetStringAsync("http://devhero.test/api/ranks").Result);
        }


        public List<Reward> GetRewards(int idUser)
        {
            throw new NotImplementedException();
        }
        User IUserService.GetUser(int id)
        {
            string json = (client.GetStringAsync("http://devhero.test/api/user/" + id).Result);
            List<User> users = JsonConvert.DeserializeObject<List<User>>(json);
            return users.First();
        }
        List<User> IUserService.GetUsers()
        {
            return JsonConvert.DeserializeObject<List<User>>(client.GetStringAsync("http://devhero.test/api/users").Result);
        }
        public List<User> GetUsersTeam(int idTeam)
        {
            return JsonConvert.DeserializeObject<List<User>>(client.GetStringAsync("http://devhero.test/api/userteam/" + idTeam).Result);
        }
    }
}
