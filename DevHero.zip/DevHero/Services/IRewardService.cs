﻿using DevHero.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DevHero.Services
{
    public interface IRewardService
    {
        List<Reward> Rewards { get; set; }
        List<Reward> GetRewards();
        List<Reward> GetRewardsPerUser(int idUser);
        List<UserReward> GetRewardsInfo(int idUser);
        List<Reward> GetReward(int idRank);
        void UseReward(int idReward, int idUser);
        void ClaimReward(int idReward);
    }
}
