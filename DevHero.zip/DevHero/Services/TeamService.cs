﻿using DevHero.Models;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace DevHero.Services
{
    class TeamService : ITeamService
    {
        public List<Team> Teams { get; set; }
        static HttpClient client = new HttpClient();


        public TeamService()
        {

        }

        public List<Team> GetTeam()
        {
          return JsonConvert.DeserializeObject<List<Team>>(client.GetStringAsync("http://devhero.test/api/team").Result);
        }


    }
}

