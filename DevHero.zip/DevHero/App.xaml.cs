﻿using DevHero.Services;
using DevHero.ViewModels;
using DevHero.Views;
using Prism.DryIoc;
using Prism.Ioc;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace DevHero
{
    public partial class App : PrismApplication
    {
        protected override async void OnInitialized()
        {
            InitializeComponent();

            await NavigationService.NavigateAsync("HomePage");
        }

        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {

            #region Navigation


            containerRegistry.RegisterForNavigation<HomePage, HomePageViewModel>();
            containerRegistry.RegisterForNavigation<LoginPage, LoginPageViewModel>();
            containerRegistry.RegisterForNavigation<ProfilView, ProfilViewViewModel>();
            containerRegistry.RegisterForNavigation<RankPage, RankPageViewModel>();
            containerRegistry.RegisterForNavigation<GamePage, GamePageViewModel>();
            containerRegistry.RegisterForNavigation<MyRewardPage, MyRewardPageViewModel>();
            containerRegistry.RegisterForNavigation<RewardPage, RewardPageViewModel>();
            containerRegistry.RegisterForNavigation<RewardStatusPage, RewardStatusPageViewModel>();
            containerRegistry.RegisterForNavigation<TabPage, TabPageViewModel>();
            containerRegistry.RegisterForNavigation<TeamPage, TeamPageViewModel>();
            containerRegistry.RegisterForNavigation<TeamInfoPage, TeamInfoPageViewModel>();
            containerRegistry.RegisterForNavigation<ShopRankPage, ShopRankPageViewModel>();
            containerRegistry.RegisterForNavigation<ShopRewardPage, ShopRewardPageViewModel>();




            #endregion
            containerRegistry.RegisterSingleton<IRankService, RankService>();
            containerRegistry.RegisterSingleton<IRewardService, RewardService>();
            containerRegistry.RegisterSingleton<IUserService, UserService>();
            containerRegistry.RegisterSingleton<ITeamService, TeamService>();
        }


    }
}
